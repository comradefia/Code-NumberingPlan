(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CodeCompare = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  function normalize(value) {
    const code = String(value ?? '').trim().replace(/^[+']/, '').replace(/[\s\u00a0-]/g, '');
    return /^\d+$/.test(code) ? code : null;
  }
  function node() { return { end: false, children: Object.create(null) }; }
  function insert(root, code) {
    let n = root;
    for (const digit of code) {
      if (n.end) return;
      n = n.children[digit] ||= node();
    }
    n.end = true;
    n.children = Object.create(null);
  }
  function tree(codes) {
    const result = node();
    for (const code of codes) insert(result, code);
    return result;
  }
  // A prefix covers every descendant, so compare the two sets as a decimal trie.
  function difference(source, target, prefix = '', output = []) {
    if (!source || target?.end) return output;
    if (!target) {
      collect(source, prefix, output);
      return output;
    }
    if (source.end) {
      for (let i = 0; i < 10; i++) {
        const digit = String(i);
        difference({ end: true }, target.children[digit], prefix + digit, output);
      }
    } else {
      for (const digit of Object.keys(source.children).sort())
        difference(source.children[digit], target.children[digit], prefix + digit, output);
    }
    return output;
  }
  function collect(n, prefix, output) {
    if (n.end) output.push(prefix);
    else for (const digit of Object.keys(n.children).sort()) collect(n.children[digit], prefix + digit, output);
  }
  function compare(reference, vendor) {
    const ref = [...new Set(reference)].sort();
    const ven = [...new Set(vendor)].sort();
    const refTree = tree(ref), venTree = tree(ven);
    const missingVendor = difference(refTree, venTree);
    const missingReference = difference(venTree, refTree);
    const describe = (codes, otherCodes, otherTree) => codes.map(code => {
      // Inspect the full opposite sheet for every source code. Both a broader
      // prefix and a narrower descendant are related, but only their union
      // decides whether this source code is fully covered.
      const matches = otherCodes.filter(other => code.startsWith(other) || other.startsWith(code));
      const uncoveredPrefixes = difference(tree([code]), otherTree);
      return {
        code, matches, matchCount: matches.length, uncoveredPrefixes,
        status: !uncoveredPrefixes.length ? 'Covered' : uncoveredPrefixes.length === 1 && uncoveredPrefixes[0] === code ? 'Missing' : 'Partial',
        uncovered: uncoveredPrefixes.length
      };
    });
    return { missingVendor, missingReference, referenceRows: describe(ref, ven, venTree), vendorRows: describe(ven, ref, refTree) };
  }
  function labelGaps(prefixes, entries) {
    return prefixes.map(code => {
      // A shorter gap can contain several more specific source destinations.
      // Include them all so a single label never conceals a distinct destination.
      const related = entries.filter(entry => code.startsWith(entry.code) || entry.code.startsWith(code));
      const sourceCodes = [...new Set(related.map(entry => entry.code))].sort();
      const destinations = [...new Set(related.map(entry => String(entry.destination ?? '').trim()).filter(Boolean))];
      return { code, sourceCodes, destinations };
    });
  }
  return { normalize, tree, difference, compare, labelGaps };
});
