(() => {
  const $ = id => document.getElementById(id);
  const state = { reference: null, vendor: null, result: null, active: 'missingVendor' };
  const tabs = { missingVendor: ['Missing on vendor', 'Reference coverage absent from vendor'], missingReference: ['Missing on reference', 'Vendor coverage absent from reference'], referenceRows: ['Reference code', 'Each reference code checked against every vendor code'], vendorRows: ['Vendor code', 'Each vendor code checked against every reference code'] };
  const fileLabel = side => $(side+'File').closest('.filebox');
  const sheetSelect = side => $(side+'Sheet');
  const colSelect = side => $(side+'Column');
  const destSelect = side => $(side+'Destination');
  function say(text, error = false) { $('message').textContent = text; $('message').classList.toggle('error', error); }
  function letter(index) { let s=''; for (let n=index+1;n;n=Math.floor((n-1)/26)) s=String.fromCharCode(65+(n-1)%26)+s; return s; }
  function inspectSheet(side) {
    const wb = state[side]; if (!wb) return;
    const name = sheetSelect(side).value;
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[name], { header: 1, defval: '', raw: false, blankrows: false });
    const width = Math.min(200, Math.max(0, ...rows.slice(0,50).map(r => r.length)));
    const first = rows[0] || [];
    const headerPattern = /dial(?:ed|led)?\s*(?:digit|number|code)|prefix|numbering\s*(?:plan|code)|^code$|^digits?$/i;
    const headerIndex = first.findIndex(v => headerPattern.test(String(v).trim()));
    const destinationIndex = first.findIndex(v => /destination|country|route\s*name|product/i.test(String(v).trim()) && !/code|digit|prefix/i.test(String(v).trim()));
    const hasHeader = headerIndex >= 0;
    wb.rows = rows; wb.hasHeader = hasHeader;
    colSelect(side).innerHTML = '';
    for (let i=0;i<width;i++) {
      const option=document.createElement('option'); option.value=String(i);
      option.textContent=`${letter(i)} · ${hasHeader ? String(first[i] ?? '').slice(0,55) || '(blank header)' : String(first[i] ?? '').slice(0,30) || '(blank)'}`;
      colSelect(side).append(option);
    }
    colSelect(side).value = String(Math.max(0, headerIndex));
    colSelect(side).disabled = !width;
    destSelect(side).innerHTML = '<option value="-1">No destination column</option>';
    for (let i=0;i<width;i++) {
      const option=document.createElement('option'); option.value=String(i);
      option.textContent=`${letter(i)} · ${hasHeader ? String(first[i] ?? '').slice(0,55) || '(blank header)' : String(first[i] ?? '').slice(0,30) || '(blank)'}`;
      destSelect(side).append(option);
    }
    destSelect(side).value = String(destinationIndex >= 0 && destinationIndex !== headerIndex ? destinationIndex : -1);
    destSelect(side).disabled = !width;
    $(side+'Info').textContent = `${wb.fileName} · ${name} · ${rows.length.toLocaleString()} rows${hasHeader ? ' (header detected)' : ''}`;
    invalidate();
  }
  function invalidate() {
    state.result = null;
    $('output').classList.add('hidden');
    $('exportXlsx').disabled = $('exportCsv').disabled = true;
    $('compare').disabled = !state.reference?.rows?.length || !state.vendor?.rows?.length;
    say($('compare').disabled ? 'Upload both files to begin.' : 'Ready to compare. Check the selected dialed digits columns.');
  }
  async function load(side, file) {
    if (!file) return;
    say(`Reading ${file.name}…`);
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data, { type: 'array', cellText: true, cellDates: false });
      if (!wb.SheetNames.length) throw new Error('No worksheets found.');
      state[side] = { Sheets: wb.Sheets, SheetNames: wb.SheetNames, fileName: file.name };
      sheetSelect(side).innerHTML = '';
      for (const name of wb.SheetNames) { const option=document.createElement('option'); option.value=name; option.textContent=name; sheetSelect(side).append(option); }
      sheetSelect(side).disabled = false;
      fileLabel(side).childNodes[0].textContent = file.name;
      inspectSheet(side);
    } catch(e) { state[side] = null; $(side+'Info').textContent = 'Could not read file'; invalidate(); say(`Could not read ${file.name}: ${e.message}`, true); }
  }
  function extract(side) {
    const wb=state[side], col=Number(colSelect(side).value), destCol=Number(destSelect(side).value), codes=[], entries=[], bad=[];
    const start=wb.hasHeader ? 1 : 0;
    for (let i=start;i<wb.rows.length;i++) {
      const value=wb.rows[i][col];
      if (value == null || String(value).trim() === '') continue;
      const code=CodeCompare.normalize(value);
      if (code) { codes.push(code); entries.push({ code, destination: destCol < 0 ? '' : String(wb.rows[i][destCol] ?? '').trim() }); }
      else bad.push(i+1);
    }
    return { codes, entries, bad };
  }
  function compare() {
    const ref=extract('reference'), ven=extract('vendor');
    if (!ref.codes.length || !ven.codes.length) { say('Both selected columns must contain at least one valid digits-only code.', true); return; }
    state.result = CodeCompare.compare(ref.codes, ven.codes);
    state.result.missingVendor = CodeCompare.labelGaps(state.result.missingVendor, ref.entries);
    state.result.missingReference = CodeCompare.labelGaps(state.result.missingReference, ven.entries);
    state.result.meta = { ref: [...new Set(ref.codes)].length, ven: [...new Set(ven.codes)].length, refBad: ref.bad.length, venBad: ven.bad.length };
    $('refCount').textContent = state.result.meta.ref.toLocaleString(); $('venCount').textContent = state.result.meta.ven.toLocaleString();
    $('missingVendorCount').textContent = state.result.missingVendor.length.toLocaleString();
    $('missingReferenceCount').textContent = state.result.missingReference.length.toLocaleString();
    $('output').classList.remove('hidden'); $('exportXlsx').disabled = $('exportCsv').disabled = false;
    const warn = ref.bad.length + ven.bad.length;
    const noDest = ['reference','vendor'].filter(side => destSelect(side).value === '-1');
    say(`Comparison complete.${warn ? ` Skipped ${ref.bad.length} reference and ${ven.bad.length} vendor rows with non-digit values.` : ''}${noDest.length ? ` Select a destination column for ${noDest.join(' and ')} to show destination names.` : ''}`);
    state.active='missingVendor'; $('search').value=''; render();
  }
  function current() {
    const arr = state.result[state.active];
    return arr.map((x,i) => ({ ...x, status: state.active.startsWith('missing') ? 'Missing' : x.status, rank:i+1 }));
  }
  function render() {
    document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === state.active)));
    const isGap = state.active.startsWith('missing');
    const opposite = state.active === 'referenceRows' ? 'Vendor' : 'Reference';
    const source = state.active === 'missingVendor' ? 'Reference' : 'Vendor';
    $('tableHead').innerHTML = `<tr><th>#</th><th>${tabs[state.active][0]}</th><th>Status</th>${isGap ? `<th>${source} code(s)</th><th>Destination from ${source}</th>` : `<th>Related ${opposite} codes</th><th>Uncovered prefixes</th>`}</tr>`;
    const query=$('search').value.trim(); const entries=current().filter(x => x.code.includes(query));
    const body=$('tableBody'); body.replaceChildren();
    // Keep rendering bounded for very large plans; the complete result remains in exports.
    for (const item of entries.slice(0,1000)) {
      const row=document.createElement('tr');
      const preview = values => values.length > 30 ? `${values.slice(0,30).join(', ')} … (+${values.length-30} more; export for all)` : values.join(', ') || '—';
      const cells=[item.rank, item.code, item.status];
      if (isGap) cells.push(preview(item.sourceCodes), preview(item.destinations));
      else cells.push(preview(item.matches), preview(item.uncoveredPrefixes));
      cells.forEach((value, index) => { const td=document.createElement('td'); if(index===1) td.className='code'; if(index===2){const badge=document.createElement('span'); badge.className=`badge ${item.status}`; badge.textContent=value; td.append(badge);} else td.textContent=value; row.append(td); });
      body.append(row);
    }
    $('empty').classList.toggle('hidden', !!entries.length);
    $('empty').textContent = query ? 'No codes match this filter.' : 'No gaps found in this direction.';
    $('resultFoot').textContent = `${entries.length.toLocaleString()} of ${state.result[state.active].length.toLocaleString()} rows${entries.length > 1000 ? ' · showing first 1,000; export for all rows' : ''} · ${tabs[state.active][1]}.`;
  }
  function download(name, blob) { const link=document.createElement('a'); link.href=URL.createObjectURL(blob); link.download=name; document.body.append(link); link.click(); link.remove(); setTimeout(()=>URL.revokeObjectURL(link.href),30000); }
  function exportCsv() {
    const isGap=state.active.startsWith('missing');
    const opposite = state.active === 'referenceRows' ? 'Vendor' : 'Reference';
    const source = state.active === 'missingVendor' ? 'Reference' : 'Vendor';
    const lines=[[tabs[state.active][0], 'Status', ...(isGap ? [`${source} code(s)`, `Destination from ${source}`] : [`Related ${opposite} codes`, 'Related code count', 'Uncovered prefixes', 'Uncovered prefix count'])], ...current().map(x=>[x.code,x.status,...(isGap?[x.sourceCodes.join('; '),x.destinations.join('; ')]:[x.matches.join('; '),x.matchCount,x.uncoveredPrefixes.join('; '),x.uncovered])])];
    const esc=v=>`"${String(v).replace(/"/g,'""')}"`;
    download(`dialed-digits-${state.active}.csv`, new Blob(['\ufeff'+lines.map(r=>r.map(esc).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));
  }
  function exportXlsx() {
    const wb=XLSX.utils.book_new(), r=state.result;
    const add=(name, rows)=>XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(rows),name);
    add('Missing on vendor', [['Dialed digit prefix','Status','Reference code(s)','Destination from reference'],...r.missingVendor.map(x=>[x.code,'Missing',x.sourceCodes.join('; '),x.destinations.join('; ')])]);
    add('Missing on reference', [['Dialed digit prefix','Status','Vendor code(s)','Destination from vendor'],...r.missingReference.map(x=>[x.code,'Missing',x.sourceCodes.join('; '),x.destinations.join('; ')])]);
    add('Reference codes', [['Reference code','Coverage in vendor','Related vendor codes','Related code count','Uncovered prefixes','Uncovered prefix count'],...r.referenceRows.map(x=>[x.code,x.status,x.matches.join('; '),x.matchCount,x.uncoveredPrefixes.join('; '),x.uncovered])]);
    add('Vendor codes', [['Vendor code','Coverage in reference','Related reference codes','Related code count','Uncovered prefixes','Uncovered prefix count'],...r.vendorRows.map(x=>[x.code,x.status,x.matches.join('; '),x.matchCount,x.uncoveredPrefixes.join('; '),x.uncovered])]);
    const data=XLSX.write(wb,{bookType:'xlsx',type:'array'});
    download('dialed-digits-comparison.xlsx',new Blob([data],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}));
  }
  for (const side of ['reference','vendor']) {
    $(side+'File').addEventListener('change',e=>load(side,e.target.files[0]));
    sheetSelect(side).addEventListener('change',()=>inspectSheet(side));
    colSelect(side).addEventListener('change',invalidate);
    destSelect(side).addEventListener('change',invalidate);
  }
  $('compare').addEventListener('click',compare); $('exportCsv').addEventListener('click',exportCsv); $('exportXlsx').addEventListener('click',exportXlsx);
  $('search').addEventListener('input',()=>state.result&&render());
  document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{state.active=b.dataset.tab; $('search').value=''; render();}));
})();
